﻿$ErrorActionPreference = 'Stop'
$port = 18766
$source = 'https://meuguia.tv/programacao/canal/'
$culture = [Globalization.CultureInfo]::InvariantCulture
$weekdays = @('domingo', 'segunda-feira', 'terça-feira', 'quarta-feira', 'quinta-feira', 'sexta-feira', 'sábado')
$cache = @{}

try {
    $sourceZone = [TimeZoneInfo]::FindSystemTimeZoneById('E. South America Standard Time')
} catch [TimeZoneNotFoundException] {
    $sourceZone = [TimeZoneInfo]::FindSystemTimeZoneById('America/Sao_Paulo')
}

function Get-SourceDay {
    return [TimeZoneInfo]::ConvertTimeFromUtc([DateTime]::UtcNow, $sourceZone).Date
}

function Get-SchedulePage([string]$channel, [datetime]$today) {
    $now = [DateTime]::UtcNow
    $entry = $cache[$channel]
    if ($entry -and $entry.Expires -gt $now -and $entry.SourceDay -eq $today) {
        return $entry.Days
    }

    Write-Host "MeuGuia: GET $channel"
    $response = $client.GetAsync($source + $channel).GetAwaiter().GetResult()
    try {
        [void]$response.EnsureSuccessStatusCode()
        $bytes = $response.Content.ReadAsByteArrayAsync().GetAwaiter().GetResult()
        $html = [Text.Encoding]::UTF8.GetString($bytes)
    } finally {
        $response.Dispose()
    }
    $html = [regex]::Replace($html, '(?s)<!--.*?-->', '')
    $list = [regex]::Match($html, '(?s)<ul class="mw">(.*?)</ul>')
    $headings = [regex]::Matches($list.Groups[1].Value,
        '<li class="subheader devicepadding">([^,<]+),\s*(\d{1,2})/(\d{1,2})</li>')
    if ($headings.Count -eq 0) { throw 'No schedule date headings returned by MeuGuia.' }

    $days = @{}
    $previous = $null
    $listing = $list.Groups[1].Value
    for ($i = 0; $i -lt $headings.Count; $i++) {
        $heading = $headings[$i]
        $date = $null
        foreach ($year in (($today.Year - 1)..($today.Year + 1))) {
            try {
                $candidate = [DateTime]::new($year, [int]$heading.Groups[3].Value, [int]$heading.Groups[2].Value)
            } catch [ArgumentOutOfRangeException] {
                continue
            }
            if ([Math]::Abs(($candidate - $today).TotalDays) -le 31 -and
                $weekdays[[int]$candidate.DayOfWeek] -eq $heading.Groups[1].Value.Trim() -and
                ($null -eq $previous -or $candidate -gt $previous)) {
                $date = $candidate
                break
            }
        }
        if ($null -eq $date) { throw "Invalid or stale MeuGuia heading: $($heading.Value)" }
        $previous = $date
        if ($date -lt $today -or $date -ge $today.AddDays(8)) { continue }
        $start = $heading.Index + $heading.Length
        $end = if ($i + 1 -lt $headings.Count) { $headings[$i + 1].Index } else { $listing.Length }
        $items = [regex]::Matches($listing.Substring($start, $end - $start),
            '(?s)<div class=[''"]lileft time[''"]>\s*((?:[01]\d|2[0-3]):[0-5]\d)\s*</div>\s*<div class="licontent">\s*<h2>(.*?)</h2>')
        $xml = [Text.StringBuilder]::new('<schedule>')
        $seen = [Collections.Generic.HashSet[string]]::new()
        foreach ($item in $items) {
            $time = $item.Groups[1].Value
            $name = [regex]::Replace($item.Groups[2].Value, '<[^>]+>', '')
            $name = [Net.WebUtility]::HtmlDecode($name).Trim()
            if ($name -and $seen.Add("$time|$name")) {
                $escaped = [Security.SecurityElement]::Escape($name)
                [void]$xml.Append("<item><t>$time</t><n>$escaped</n></item>")
            }
        }
        [void]$xml.Append('</schedule>')
        $days[$date.ToString('yyyy-MM-dd', $culture)] = $xml.ToString()
    }
    $cache[$channel] = @{ Expires = $now.AddMinutes(10); SourceDay = $today; Days = $days }
    return $days
}

Add-Type -AssemblyName System.Net.Http
$handler = [Net.Http.HttpClientHandler]::new()
$handler.AutomaticDecompression = [Net.DecompressionMethods]::GZip -bor [Net.DecompressionMethods]::Deflate
$client = [Net.Http.HttpClient]::new($handler)
$client.Timeout = [TimeSpan]::FromSeconds(20)
$client.DefaultRequestHeaders.UserAgent.ParseAdd('MeuGuia-KIT/1.0')
$listener = [Net.HttpListener]::new()
$listener.Prefixes.Add("http://127.0.0.1:$port/")
try {
    $listener.Start()
    Write-Host "MeuGuia proxy: http://127.0.0.1:$port/ (leave open while KIT updates)"
    while ($listener.IsListening) {
        $context = $listener.GetContext()
        $reply = $context.Response
        try {
            $reply.ContentType = 'text/xml; charset=utf-8'
            $path = $context.Request.Url.AbsolutePath
            $route = [regex]::Match($path, '^/schedule/([A-Z0-9]{1,12})/(\d{4}-\d{2}-\d{2})$')
            $body = '<schedule/>'
            if ($context.Request.HttpMethod -ne 'GET' -or -not $route.Success) {
                $reply.StatusCode = 404
            } else {
                $channel = $route.Groups[1].Value
                $iso = $route.Groups[2].Value
                $date = [DateTime]::MinValue
                if (-not [DateTime]::TryParseExact($iso, 'yyyy-MM-dd', $culture, [Globalization.DateTimeStyles]::None, [ref]$date)) {
                    $reply.StatusCode = 400
                } else {
                    $today = Get-SourceDay
                    if ($date -ge $today -and $date -lt $today.AddDays(8)) {
                        $days = Get-SchedulePage $channel $today
                        if ($days.ContainsKey($iso)) { $body = $days[$iso] }
                    }
                }
            }
        } catch {
            Write-Warning $_.Exception.Message
            $reply.StatusCode = 502
            $body = '<schedule/>'
        }
        try {
            $bytes = [Text.Encoding]::UTF8.GetBytes($body)
            $reply.ContentLength64 = $bytes.Length
            $reply.OutputStream.Write($bytes, 0, $bytes.Length)
        } catch [Net.HttpListenerException] {
            Write-Warning 'KIT closed the request before the response was sent.'
        } finally {
            $reply.Close()
        }
    }
} finally {
    $listener.Close()
    $client.Dispose()
}
