@echo off
title MeuGuia Proxy for KIT
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0proxy.ps1"
if errorlevel 1 pause
