"""Export programme titles and times loaded by the EON website to XMLTV."""
import argparse
from datetime import datetime, timezone
from pathlib import Path
from urllib.parse import parse_qs, urlsplit
import xml.etree.ElementTree as ET

from playwright.sync_api import TimeoutError as BrowserTimeout
from playwright.sync_api import sync_playwright

EON = "https://eontv.bg"
API = "api-web-public.vivacom-be.cdn.united.cloud"


def collect(ids, browser_name, executable):
    names = {}
    guides = {}
    with sync_playwright() as playwright:
        options = {"executable_path": executable} if executable else {}
        if browser_name != "chromium":
            options["channel"] = browser_name
        browser = playwright.chromium.launch(**options)
        page = browser.new_page(locale="bg-BG", timezone_id="Europe/Sofia")

        def observe(response):
            url = urlsplit(response.url)
            if url.hostname != API or not response.ok:
                return
            params = parse_qs(url.query)
            if url.path == "/public/v2/channels" and params.get("channelType") == ["TV"]:
                names.update({item["id"]: item["name"] for item in response.json()})
            if url.path == "/public/v3/events/epg":
                channel = int(params["cid"][0])
                guides.setdefault(channel, {})[params["date"][0]] = response.json()

        page.on("response", observe)
        for channel in ids:
            page.goto(f"{EON}/tv/channel/{channel}", wait_until="domcontentloaded", timeout=60000)
            reject = page.get_by_role("button", name="Отхвърляне на всички", exact=True)
            for _ in range(120):
                if len(guides.get(channel, {})) >= 3:
                    break
                if reject.is_visible():
                    try:
                        reject.click(timeout=1500)
                    except BrowserTimeout:
                        pass
                page.wait_for_timeout(500)
            batches = guides.get(channel, {})
            if not any(batches.values()) or channel not in names:
                raise RuntimeError(f"EON не віддав розклад або назву каналу {channel}.")
            print(f"{names[channel]}: {', '.join(sorted(batches))}")
    return names, guides


def stamp(milliseconds):
    return datetime.fromtimestamp(milliseconds / 1000, timezone.utc).strftime("%Y%m%d%H%M%S +0000")


def save_xmltv(output, ids, names, guides):
    tv = ET.Element("tv", {"source-info-name": "EON TV Bulgaria"})
    for channel in ids:
        node = ET.SubElement(tv, "channel", id=f"eontv.bg.{channel}")
        ET.SubElement(node, "display-name", lang="bg").text = names[channel]
    for channel in ids:
        events = {event["id"]: event for batch in guides[channel].values() for event in batch}
        for event in sorted(events.values(), key=lambda item: item["startTime"]):
            if not event.get("title") or event["endTime"] <= event["startTime"]:
                continue
            node = ET.SubElement(tv, "programme", {
                "channel": f"eontv.bg.{channel}",
                "start": stamp(event["startTime"]),
                "stop": stamp(event["endTime"]),
            })
            ET.SubElement(node, "title", lang="bg").text = event["title"]
    ET.indent(tv)
    temporary = output.with_suffix(output.suffix + ".tmp")
    ET.ElementTree(tv).write(temporary, encoding="utf-8", xml_declaration=True)
    temporary.replace(output)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--channel", type=int, nargs="+", default=[82], help="Номери з адрес /tv/channel/<номер>")
    parser.add_argument("--output", type=Path, default=Path("eontv.xml"))
    parser.add_argument("--browser", choices=["chromium", "chrome", "msedge"], default="chromium")
    parser.add_argument("--executable")
    args = parser.parse_args()
    ids = list(dict.fromkeys(args.channel))
    if any(channel < 1 for channel in ids):
        parser.error("Номери каналів мають бути додатними.")
    names, guides = collect(ids, args.browser, args.executable)
    save_xmltv(args.output, ids, names, guides)
    print(f"XMLTV: {args.output.resolve()}")


if __name__ == "__main__":
    main()
