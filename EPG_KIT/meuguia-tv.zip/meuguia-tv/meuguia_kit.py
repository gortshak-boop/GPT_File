"""Serve MeuGuia channel listings and calendar-day schedules to KIT."""
import argparse
from datetime import date, datetime, time
from functools import lru_cache
from html import escape, unescape
from http.server import BaseHTTPRequestHandler, HTTPServer
import re
from time import monotonic
from urllib.error import URLError
from urllib.parse import urlsplit
from urllib.request import Request, urlopen
from zoneinfo import ZoneInfo

SITE = "https://meuguia.tv"
CATEGORIES = ("Filmes", "Series", "Esportes", "Infantil", "Variedades",
              "Documentarios", "Noticias", "Aberta")
WEEKDAYS = ("segunda-feira", "terça-feira", "quarta-feira", "quinta-feira",
            "sexta-feira", "sábado", "domingo")
HEADER = re.compile(r'<li class="subheader devicepadding">([^,<]+),\s*(\d{1,2})/(\d{1,2})</li>')
EVENT = re.compile(r"<div class=['\"]lileft time['\"]>\s*(\d{2}:\d{2})\s*</div>"
                   r'\s*<div class="licontent">\s*<h2>(.*?)</h2>', re.S)
CHANNEL = re.compile(r'href="/programacao/canal/([A-Za-z0-9]+)"[^>]*>'
                     r'(?:(?!</a>).)*?<h2>(.*?)</h2>', re.S)
PORT = 18765


def clean_markup(html):
    return re.sub(r'<!--.*?-->', '', html, flags=re.S)


def plain(value):
    return " ".join(unescape(re.sub(r'<[^>]+>', '', value)).split())


@lru_cache(maxsize=128)
def cached_page(path, refresh_slot):
    request = Request(SITE + path, headers={"User-Agent": "MeuGuia-KIT/1.0"})
    with urlopen(request, timeout=20) as response:
        return response.read().decode("utf-8")


def fetch(path):
    return cached_page(path, int(monotonic() // 600))


def channel_rows():
    channels = {}
    for category in CATEGORIES:
        html = clean_markup(fetch(f"/programacao/categoria/{category}"))
        for code, name in CHANNEL.findall(html):
            channels[code] = plain(name)
    if not channels:
        raise ValueError("MeuGuia не повернув список каналів.")
    return channels


def source_date(day, month, weekday, anchor, previous):
    candidates = []
    for year in range(anchor.year - 1, anchor.year + 2):
        try:
            candidate = date(year, month, day)
        except ValueError:
            continue
        if WEEKDAYS[candidate.weekday()] != weekday or (previous and candidate <= previous):
            continue
        if abs((candidate - anchor).days) <= 31:
            candidates.append(candidate)
    if not candidates:
        raise ValueError(f"Дата сайту не узгоджується з календарем: {weekday}, {day}/{month}")
    return min(candidates, key=lambda value: abs((value - anchor).days))


def events(html, anchor, source_zone):
    html = clean_markup(html)
    blocks = list(HEADER.finditer(html))
    if not blocks:
        raise ValueError("На сторінці каналу немає дат розкладу.")
    previous = None
    seen = set()
    result = []
    for i, header in enumerate(blocks):
        weekday, day, month = header.groups()
        previous = source_date(int(day), int(month), weekday.strip(), anchor, previous)
        end = blocks[i + 1].start() if i + 1 < len(blocks) else len(html)
        for clock, title in EVENT.findall(html[header.end():end]):
            stamp = datetime.combine(previous, time.fromisoformat(clock), source_zone)
            item = (stamp, plain(title))
            if item[1] and item not in seen:
                seen.add(item)
                result.append(item)
    return sorted(result)


def schedule_rows(html, requested, source_zone, target_zone, anchor):
    result = []
    for stamp, title in events(html, anchor, source_zone):
        local = stamp.astimezone(target_zone)
        if local.date() == requested:
            result.append(f'<event><time>{local:%H:%M}</time><title>{escape(title)}</title></event>')
    return result


class Guide(BaseHTTPRequestHandler):
    def do_GET(self):
        path = urlsplit(self.path).path
        match = re.fullmatch(r'/schedule/([A-Za-z0-9]+)/([0-9]{4}-[0-9]{2}-[0-9]{2})', path)
        try:
            if path == "/channels":
                rows = ['<region>Brasil</region>']
                style = fetch("/meuguia.css?5.1.0")
                logos = dict(re.findall(
                    r'\.canal_([a-z0-9]+)\s*\{[^}]*?url\((https://assets\.meuguia\.tv/logos/[a-z0-9]+\.png[^)]*)\)',
                    style,
                ))
                for code, name in channel_rows().items():
                    icon = logos.get(code.lower(), SITE + "/apple-touch-icon.png")
                    rows.append(f'<channel code="{code}" name="{escape(name)}" icon="{escape(icon)}">')
            elif match:
                code, day = match.groups()
                requested = date.fromisoformat(day)
                source_zone = ZoneInfo("America/Sao_Paulo")
                rows = schedule_rows(fetch(f"/programacao/canal/{code}"), requested,
                                     source_zone, self.server.target,
                                     datetime.now(source_zone).date())
            else:
                self.send_error(404)
                return
        except (URLError, TimeoutError, ValueError) as error:
            self.log_error("%s", error)
            self.send_error(502, "MeuGuia data unavailable")
            return
        content = ("<guide>\n" + "\n".join(rows) + "\n</guide>").encode("utf-8")
        self.send_response(200)
        self.send_header("Content-Type", "text/plain; charset=utf-8")
        self.send_header("Content-Length", str(len(content)))
        self.end_headers()
        self.wfile.write(content)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--timezone", default="Europe/Kyiv", help="IANA time zone for the KIT calendar")
    args = parser.parse_args()
    server = HTTPServer(("127.0.0.1", PORT), Guide)
    server.target = ZoneInfo(args.timezone)
    print(f"MeuGuia для КИТ: http://127.0.0.1:{PORT} ({server.target})", flush=True)
    with server:
        try:
            server.serve_forever()
        except KeyboardInterrupt:
            pass


if __name__ == "__main__":
    main()
